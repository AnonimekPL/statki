#include "statki.hpp"

int main()
{
	gra gra1;
	return 0;
}